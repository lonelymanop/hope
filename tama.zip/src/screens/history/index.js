import {View, Text} from 'react-native';
import React from 'react';
import DrawerSceneWrapper from '../../components/DrawerSceneWrapper';

const History = () => {
  return (
    <DrawerSceneWrapper>
      <View>
        <Text>History</Text>
      </View>
    </DrawerSceneWrapper>
  );
};

export default History;
