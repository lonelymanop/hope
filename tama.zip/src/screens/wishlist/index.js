import React from 'react';
import { View, FlatList, Text, Image, TouchableOpacity, StyleSheet } from 'react-native';

const TeamMemberCard = ({ name, email, designation }) => (
  <View style={styles.cardContainer}>
    <View style={styles.cardContent}>
      {/* <Image source={require('')} style={styles.avatar} /> */}
      <View style={styles.memberInfo}>
        <Text style={styles.name}>{name}</Text>
        <Text style={styles.email}>{email}</Text>
        <Text style={styles.designation}>{designation}</Text>
      </View>
    </View>
    <TouchableOpacity style={styles.moreButton}>
      <Text style={styles.moreButtonText}>...</Text>
    </TouchableOpacity>
  </View>
);

const TeamPage = () => {
  const teamData = [
    { id: '1', name: 'Ben Jocken', email: 'ben.jocken07@gmail.com', designation: 'UI Designer',  },
    { id: '2', name: 'Diana Kim', email: 'diana.kim94@gmail.com', designation: 'Graphic Designer' },
    // Add more team members here
  ];

  return (
    <View style={styles.container}>
    <Text classname="text-3xl font-bold ">Wishlist</Text>
      <FlatList
        data={teamData}
        keyExtractor={(item) => item.id}
        renderItem={({ item }) => (
          <TeamMemberCard
            name={item.name}
            email={item.email}
            designation={item.designation}
          />
        )}
      />
    </View>
  );
};

const styles = StyleSheet.create({
  container: {
    flex: 1,
    backgroundColor: '#f8f8f8',
    padding: 16,
    paddingTop: 40,
  },
  cardContainer: {
    backgroundColor: '#fff',
    borderRadius: 8,
    flexDirection: 'row',
    alignItems: 'center',
    justifyContent: 'space-between',
    paddingVertical: 16,
    paddingHorizontal: 12,
    marginBottom: 16,
    shadowColor: '#000',
    shadowOffset: {
      width: 0,
      height: 2,
    },
    shadowOpacity: 0.1,
    shadowRadius: 4,
    elevation: 2,
  },
  cardContent: {
    flexDirection: 'row',
    alignItems: 'center',
  },
  avatar: {
    width: 40,
    height: 40,
    borderRadius: 20,
    marginRight: 12,
  },
  memberInfo: {
    flex: 1,
  },
  name: {
    fontSize: 16,
    fontWeight: 'bold',
    marginBottom: 4,
  },
  email: {
    fontSize: 14,
    color: '#555',
    marginBottom: 4,
  },
  designation: {
    fontSize: 14,
    color: '#777',
  },
  moreButton: {
    paddingHorizontal: 12,
    paddingVertical: 8,
  },
  moreButtonText: {
    fontSize: 18,
    color: '#999',
  },
});

export default TeamPage;