import * as React from 'react';
import { Button, Image, Text, TouchableOpacity, View } from 'react-native';
import {
  AnimatedTabBarNavigator,
  DotSize,
  TabElementDisplayOptions,
  TabButtonLayout
} from 'react-native-animated-nav-tab-bar';
import Icon from 'react-native-vector-icons/Feather';
import Dashboard from '../screens/dashboard';
import styled from 'styled-components/native';
import { useNavigation } from '@react-navigation/native';
const Screen = styled.View`
  flex: 1;
  justify-content: center;
  align-items: center;
  background-color: #f2f2f2;
`;

const Tabs = AnimatedTabBarNavigator();

const Home = (props) => (
  <Screen>
    <Logo />
    <Text>Home</Text>
    <TouchableOpacity onPress={() => props.navigation.navigate('AddEmployee')}>
      <Text style={{ color: 'blue', fontSize: 20, paddingTop: 23, padding: 12 }}>Add Employee</Text>
    </TouchableOpacity>




  </Screen>
);

const Logo = () => (
  <Image
    source={require('./logo.png')}
    resizeMode={'cover'}
    style={{ width: 150, height: 150 }}
  />
);

const TabBarIcon = (props) => {
  return (
    <Icon
      name={props.name}
      size={props.size ? props.size : 24}
      color={props.tintColor}
    />
  );
};


import { Dimensions, StyleSheet } from 'react-native';
import Wishlist from '../screens/wishlist';

const { width } = Dimensions.get('window');
const desiredTabBarWidth = width * 0.6; // 50% of the screen width

const styles = StyleSheet.create({
  tabBar: {
    width: desiredTabBarWidth,
    alignSelf: 'flext-start', // Center the tab bar horizontally
  },
});
const Bottom = () => {

  const navigation = useNavigation();
  return (<>
    <Tabs.Navigator
      initialRouteName="Home"
      tabBarOptions={{
        activeTintColor: '#ffffff',
        inactiveTintColor: '#223322',
        activeBackgroundColor: '#009688',
        tabStyle: styles.tabBar,
      }}
      appearance={{
        topPadding: 10,
        bottomPadding: 10,
        horizontalPadding: 10,
        tabBarBackground: "#FFFFFF",
        floating: true,
        dotCornerRadius: 100,
        whenActiveShow: TabElementDisplayOptions.BOTH,
        whenInactiveShow: TabElementDisplayOptions.ICON_ONLY,
        shadow: true,
        dotSize: DotSize.DEFAULT,
        tabButtonLayout: TabButtonLayout.HORIZONTAL,
        tabBarWidth: '1000%',
        // activeColors: undefined,
        // activeTabBackgrounds: undefined,
      }}>
      <Tabs.Screen
        name="Home"
        component={Dashboard}
        options={{
          tabBarIcon: ({ focused, color }) => (
            <TabBarIcon focused={focused} tintColor={color} name="home" />
          ),
        }}
      />
      <Tabs.Screen
        name="Employee"
        component={Home}
        options={{
          tabBarIcon: ({ focused, color }) => (
            <TabBarIcon focused={focused} tintColor={color} name="search" />
          ),
        }}
      />
      <Tabs.Screen
        name="Images"
        component={Wishlist}
        options={{
          tabBarIcon: ({ focused, color }) => (
            <TabBarIcon focused={focused} tintColor={color} name="image" />
          ),
        }}
      />
    </Tabs.Navigator>

    <View style={{ width: '100%', height: 40,position:'absolute',top:60,justifyContent:'center',alignItems:'center' }}>

    {/* <Image
      source={require('../../assets/images/wareozo-black.png')}
      resizeMode={'cover'}
      style={{ width: 150, height: 40}}
    /> */}
    </View>


    <TouchableOpacity
      style={{
        position: 'absolute',
        bottom: 28,
        right: 50,
        backgroundColor: 'lightgreen',
        borderRadius: 30,
        padding: 12,
        width: 55,
        height: 55,
        justifyContent: 'center',
        alignItems: 'center',
      }}
      onPress={() => navigation.getParent('RightDrawer').openDrawer()}
    >
      <Icon name="home" size={20} color="black" />
    </TouchableOpacity>
</>
  );
};

export default Bottom;
