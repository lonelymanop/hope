import { View,Platform} from 'react-native';
import React from 'react'
import Bottom from '../bottom'
import DrawerSceneWrapper from '../../components/DrawerSceneWrapper';

export default function Main({navigation}) {
    const {openDrawer} = navigation;
    return (
        <DrawerSceneWrapper>
            {/* <SafeAreaView style={styles.container}> */}
                <View style={{backgroundColor: '#fff', flex: 1, borderRadius:  Platform.OS === 'android' ? 20 : 50,overflow:'hidden'}}>
                    <Bottom/>
                </View>
            {/* </SafeAreaView> */}
        </DrawerSceneWrapper>
    )
}