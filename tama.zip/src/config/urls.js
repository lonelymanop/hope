export const API_BASE_URL = "http://stage.myinbook.com/stage-api/api";
export const getApiUrl = (endpoint) => API_BASE_URL + endpoint



export const LOGIN = getApiUrl('/v1/login');
export const SIGNUP = getApiUrl('/v1/register');
export const SENDOTP = getApiUrl('/v1/user/otp');
export const RESETPASSWORD = getApiUrl('/v1/resetPassword');
export const FORGOTPASSWORD = getApiUrl('/v1/forgotPassword');
