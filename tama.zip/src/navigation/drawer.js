import React from 'react';
import Icon from 'react-native-vector-icons/MaterialCommunityIcons';
import {createDrawerNavigator, useDrawerProgress} from '@react-navigation/drawer';
import Dashboard from '../screens/dashboard';
import Wishlist from '../screens/wishlist';
import History from '../screens/history';
import Login from '../screens/Login';
import Main from './pages/Main';
import { Button, Platform, Text, View, useWindowDimensions } from 'react-native';
import Animated, {interpolate, useAnimatedStyle} from 'react-native-reanimated';

const Drawer = createDrawerNavigator();

const DrawerNavigator = () => {
  const drawerIcon = ({focused, size}, name) => {
    return (
      <Icon
        name={name}
        size={20}
        style={{marginLeft:10,marginRight:-20}}
        color={focused ? Colors.active : Colors.inactive}
      />
    );
  };
  return (
    <Drawer.Navigator
      drawerType="slide"
      id="LeftDrawer"
      screenOptions={{
        headerShown: false,
        // drawerPosition:'right',
        drawerActiveBackgroundColor: "red",
        drawerInactiveBackgroundColor: Colors.transparent,
        drawerActiveTintColor: Colors.active,
        drawerInactiveTintColor: Colors.inactive,
        drawerHideStatusBarOnOpen: true,
        overlayColor: Colors.transparent,
        drawerStyle: {
          backgroundColor: Colors.bg,
          width: '50%',
          paddingTop:"70%"
        },
        sceneContainerStyle: {
          backgroundColor: Colors.bg,
        },
        drawerLabelStyle: {
          fontSize:16
        },
        drawerItemStyle: {
          backgroundColor: "#00a898",
          borderRadius:12,
          marginLeft:15
        }
      }}
    >
      <Drawer.Screen
        name="Dashboard"
        component={Main}
        options={{
          drawerIcon: options => drawerIcon(options, 'home-outline'),
          drawerItemStyle : {
            backgroundColor:'#00877a',
            borderRadius:12,
            marginLeft:15
          }
        }}
      />
      <Drawer.Screen
        name="Sales"
        component={Login}
        options={{
          drawerIcon: options => drawerIcon(options, 'heart-outline'),
        }}
      />
      <Drawer.Screen
        name="Purchases"
        component={Dashboard}
        options={{
          drawerIcon: options => drawerIcon(options, 'history'),
        }}
      />
      <Drawer.Screen
        name="Items"
        component={Dashboard}
        options={{
          drawerIcon: options => drawerIcon(options, 'history'),
        }}
      />
      <Drawer.Screen
        name="Reports"
        component={Dashboard}
        options={{
          drawerIcon: options => drawerIcon(options, 'history'),
        }}
      />
      <Drawer.Screen
        name="Settings"
        component={Dashboard}
        options={{
          drawerIcon: options => drawerIcon(options, 'history'),
        }}
      />
    </Drawer.Navigator>
  );
};

// export default DrawerNavigator;

const Colors = {
  bg: '#009688',
  active: '#fff',
  inactive: '#eee',
  transparent: 'transparent',
};

const RightDrawer = createDrawerNavigator();

function RightDrawerScreen() {
  
  return (
    <RightDrawer.Navigator
      drawerType="slide"
      id="RightDrawer"
      drawerContent={(props) => <RightDrawerContent {...props} />}
      screenOptions={{
        swipeEdgeWidth: 0,
        headerShown: false,
        drawerPosition:'right',
        drawerActiveBackgroundColor: "red",
        drawerInactiveBackgroundColor: Colors.transparent,
        drawerActiveTintColor: Colors.active,
        drawerInactiveTintColor: Colors.inactive,
        drawerHideStatusBarOnOpen: false,
        overlayColor: Colors.transparent,
        drawerStyle: {
          backgroundColor: Colors.bg,
          width: '0.01%',
          paddingTop:"70%"
        },
        sceneContainerStyle: {
          backgroundColor: Colors.bg,
        },
        drawerLabelStyle: {
          fontSize:16
        },
        drawerItemStyle: {
          backgroundColor: "#00a898",
          borderRadius:12,
          marginLeft:15
        }
      }}
    >
      <RightDrawer.Screen name="RightItems" component={DrawerSceneWrapperRight}
      //  component={() => { return <DrawerSceneWrapper><DrawerNavigator/></DrawerSceneWrapper>}} 
       />
    </RightDrawer.Navigator>
  );
}

function RightDrawerContent({navigation} ) {
  // const {openDrawer} = navigation.getParent('LeftDrawer');
  return (
    <View style={{ flex: 1, alignItems: 'center', justifyContent: 'center' }}>
      {/* <Button
        title="Open left drawer"
      /> */}
    </View>
  );
}

const DrawerSceneWrapperRight = () => {
  const progress = useDrawerProgress();
  const {width} = useWindowDimensions();
  console.log(progress.value);

  // const animatedStyle = useAnimatedStyle(() => ({
  //   transform: [
  //     {perspective: 1000},
  //     {
  //       scale: interpolate(progress.value, [0, 1], [1, 0.75], 'clamp'),
  //     },
  //     {
  //       rotate: `${interpolate(progress.value, [0, 0], [20, 0], 'clamp')}deg`,
  //     },
  //     {
  //       translateX: interpolate(
  //         progress.value,
  //         [0, 1],
  //         [0, Platform.OS === 'android' ? width - 130 : -120],
  //         'clamp',
  //       ),
  //     },
  //   ],
  //   borderRadius: interpolate(progress.value, [0, 1], [0, 40], 'clamp'),
  //   overflow: 'hidden',
  // }));

  const animatedStyle = useAnimatedStyle(() => ({
    transform: [
      // {perspective: 1000},
      {
        scale: interpolate(progress.value, [0, 1], [1, 0.85], 'clamp'),
      },
      {
        // rotateY: `${interpolate(progress.value, [0, 1], [0, -20], 'clamp')}deg`,
        rotateZ: `${interpolate(progress.value, [0, 1], [0, 20], 'clamp')}deg`,
      },
      {
        translateX: interpolate(
          progress.value,
          [0, 1],
          [0, Platform.OS === 'android' ? -180 : -180],
          'clamp',
        )
      },
      {
        translateY: interpolate(
          progress.value,
          [0, 1],
          [0, Platform.OS === 'android' ? -150 : -150],
          'clamp',
        )
      },
    ],
    borderRadius: interpolate(progress.value, [0, 1], [0, 40], 'clamp'),
    overflow: 'hidden',
  }));

  return (
    <Animated.View style={[{
      flex: 1,
    }, animatedStyle]}>
      <DrawerNavigator/>
    </Animated.View>
  );
};

export default RightDrawerScreen;