import React, { useEffect } from "react";
import { View, Text, Image, TextInput, TouchableOpacity, StyleSheet , ScrollView} from 'react-native' 
import { useNavigation } from "@react-navigation/native";
// import { ScrollView } from "react-native-reanimated/lib/typescript/Animated";

export default function SendOTP() {
    const navigation = useNavigation();
  return (
    <ScrollView className='w-full h-full bg-[#f7f7f7]'>
    <View className="bg-white flex flex-row justify-center item-center w-full h-full">
      <View className="bg-white w-full h-full bg-[#f7f7f7]">
        <Text className="pt-28 [font-family:'Poppins-SemiBold']  text-dark text-2xl text-center  leading-[normal] whitespace-nowrap">
          Verify OTP
        </Text>
        <View className="p-3 mt-20">

            <View className="flex flex-row p-2"> 
              <View className="w-[16.66%] pl-1.5 pr-1.5">
                <TextInput style={styles.shadow} className="[font-family:'Poppins-Medium'] text-3xl bg-white  rounded-[16px] p-3 pt-4 pl-3.5 pb-[1]" inputMode="numeric" caretHidden={true} placeholderTextColor={'gray'}/>
              </View>
              <View className="w-[16.66%] pl-1.5 pr-1.5">
                <TextInput style={styles.shadow} className="[font-family:'Poppins-Medium'] text-3xl bg-white  rounded-[16px] p-3 pt-4 pl-3.5 pb-[1]" inputMode="numeric" caretHidden={true} placeholderTextColor={'gray'}/>
              </View>
              <View className="w-[16.66%] pl-1.5 pr-1.5">
                <TextInput style={styles.shadow} className="[font-family:'Poppins-Medium'] text-3xl bg-white  rounded-[16px] p-3 pt-4 pl-3.5 pb-[1]" inputMode="numeric" caretHidden={true} placeholderTextColor={'gray'}/>
              </View>
              <View className="w-[16.66%] pl-1.5 pr-1.5">
                <TextInput style={styles.shadow} className="[font-family:'Poppins-Medium'] text-3xl bg-white  rounded-[16px] p-3 pt-4 pl-3.5 pb-[1]" inputMode="numeric" caretHidden={true} placeholderTextColor={'gray'}/>
              </View>
              <View className="w-[16.66%] pl-1.5 pr-1.5">
                <TextInput style={styles.shadow} className="[font-family:'Poppins-Medium'] text-3xl bg-white  rounded-[16px] p-3 pt-4 pl-3.5 pb-[1]" inputMode="numeric" caretHidden={true} placeholderTextColor={'gray'}/>
              </View>
              <View className="w-[16.66%] pl-1.5 pr-1.5">
                <TextInput style={styles.shadow} className="[font-family:'Poppins-Medium'] text-3xl bg-white  rounded-[16px] p-3 pt-4 pl-3.5 pb-[1]" inputMode="numeric" caretHidden={true} placeholderTextColor={'gray'}/>
              </View>
            </View>

            <View className="p-3 mt-1 "> 
                <TouchableOpacity style={styles.shadow} className="w-full bg-sky-400 p-4 rounded-[16px] mb-3" onPress={()=> navigation.push('Parent')}> 
                    <Text className="text-xl text-white [font-family:'Poppins-SemiBold'] text-center">Verify OTP</Text> 
                </TouchableOpacity> 
            </View>
        </View>
      </View>
    </View>
    </ScrollView>
  );
};

const styles = StyleSheet.create({  
    shadow: {  
        // box-shadow: rgba(99, 99, 99, 0.2) 0px 2px 8px 0px;
        // box-shadow: rgba(149, 157, 165, 0.2) 0px 8px 24px;
        // boxShadow: 'rgba(0, 0, 0, 0.35) 0px 5px 15px',
        shadowOffset: { height: 8,width:0 },
        shadowColor: 'rgba(149, 157, 165, 0.2)',  
        shadowOpacity: 0.3,  
        elevation: 3,
        zIndex:999,  
        textAlignVertical : 'top'
    }
});

// text-[#34c2c1]