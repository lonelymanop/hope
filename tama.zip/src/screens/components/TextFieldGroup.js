import { Button, Modal, Platform, StyleSheet, Text, TextInput, TouchableOpacity, View } from 'react-native'
import React, { useState } from 'react'
import Divider from '../../components/Divider'
import RNDateTimePicker from '@react-native-community/datetimepicker'
import Animated, { FadeIn, FadeInDown, FadeInUp, FadeOutDown, SlideInDown, SlideInUp } from 'react-native-reanimated';
import DatePicker, { getFormatedDate } from 'react-native-modern-datepicker';
import moment from 'moment';
import SegmentedControl from '@react-native-segmented-control/segmented-control';
import { Checkbox } from 'react-native-paper';
import { useNavigation } from '@react-navigation/native';
import CustomSelect from './CustomSelect';

export default function TextFieldGroup({ data, title }) {

  const [showDate, setShowDate] = useState([]);
  const [selectedDate, setSelectedDate] = useState([]);

  const navigation = useNavigation();

  const [radio, setRadio] = useState([]);
  const [check, setCheck] = useState([]);
  

  return (
    <>
    {title && <Text className="mt-4 [font-family:'Poppins-Regular'] tracking-wider text-[13px] pl-[15]  w-full color-[#8e8e8e]">{String(title).toUpperCase()}</Text>}
    <View style={styles.container} className={`bg-white  z-[-1] rounded-[10px] ${title ? 'mt-1' : 'mt-4'}`}>
      {data && data.map((e, i)=> {
        return (
          <View key={i}>
          
        {e.type === 'select' ? <>
          {/* <CustomSelect/> */}
          </>
        :
          <View className="flex flex-row rounded-[10px] " style={{ display: e.visible === false ? 'none' : 'flex',backgroundColor: showDate[i] ? '#eeeeef' : '#ffff'}}> 

              {e.label && <View className={`${e.type === 'phone' ? 'w-[47%]' : 'w-[45%]'} pr-2`}>
                <TextInput
                  placeholder='Search State' editable={false} value={e.title} multiline={e.type === 'textarea'}
                  className={`[font-family:'Poppins-Regular'] tracking-wide ${Platform.OS === 'ios' ? 'text-base p-3 pl-4' : "text-sm p-2 pl-4"}  w-full color-[#040404]`}
                />
              </View>}

              {e.type === 'phone' && <View className={e.label ? "w-[16%] pt-2 pb-2" : 'w-[12%] pt-2 pb-2'}>
                <TextInput
                  placeholder='Search State' editable={false} value={'+91'}
                  className={`[font-family:'Poppins-Regular'] tracking-wide text-right w-full color-[#8e8e8e] ${Platform.OS === 'ios' ? 'text-base pt-1' : "text-sm pt-[-20]"}`}
                />
              </View>}

              <View className={e.label ? e.type === 'phone' ? 'w-[37%]' : 'w-[55%]' : e.type === 'phone' ? 'w-[88%]' : 'w-full'}>

                { e.type === 'text' ? 

                  <TextInput
                    placeholder={`Enter ${e.title}`} spellCheck={false} placeholderTextColor={'#c7c7c9'}
                    className={`[font-family:'Poppins-Regular'] tracking-wide  ${Platform.OS === 'ios' ? 'text-base p-3 pl-0 pr-4' : "text-sm p-2 pl-0 pr-4"} ${e.label ? 'text-right' : 'pl-4'} w-full color-[#8e8e8e]`}
                  /> 
                  
                : e.type === 'number' ? 

                  <TextInput
                    placeholder={`Enter ${e.title}`} spellCheck={false} placeholderTextColor={'#c7c7c9'} inputMode='numeric'
                    className={`[font-family:'Poppins-Regular'] tracking-wide  ${Platform.OS === 'ios' ? 'text-base p-3 pl-0 pr-4' : "text-sm p-2 pl-0 pr-4"} ${e.label ? 'text-right' : 'pl-4'} text-base w-full color-[#8e8e8e]`}
                  /> 
                  
                : e.type === 'phone' ? 

                  <TextInput
                    placeholder={`XXXXXXXXXX`} spellCheck={false} placeholderTextColor={'#c7c7c9'} inputMode='numeric'
                    className={`[font-family:'Poppins-Regular'] tracking-wide ${Platform.OS === 'ios' ? 'text-base p-3 pl-0 pr-4' : "text-sm p-2 pl-0 pr-4"} ${e.label ? 'text-right' : 'pl-4'} w-full color-[#8e8e8e]`}
                  /> 
                  
                : e.type === 'textarea' ? 

                  <TextInput multiline={true} numberOfLines={e.lines}
                    style={[{textAlignVertical: 'top'},{height: 50 + 26 * (e.lines -1)}]}
                    placeholder={`Enter ${e.title}`} spellCheck={false} placeholderTextColor={'#c7c7c9'}
                    className={`[font-family:'Poppins-Regular'] tracking-wide ${Platform.OS === 'ios' ? 'text-base p-3 pl-0 pr-4' : "text-sm p-2 pl-0 pr-4"} ${e.label ? 'text-right' : 'pl-4'} w-full color-[#8e8e8e] pl-4`}
                  /> 
                
                : e.type === 'date' ?

                  <TouchableOpacity 
                    style={{backgroundColor : 'transparent'}} className="p-3 pt-3.5 rounded-[16px]" 
                    onPress={()=> {
                      const cureentShow = [...showDate];
                      cureentShow[i] = !cureentShow[i];
                      setShowDate(cureentShow)
                    }}
                  > 
                    <Text className={`${Platform.OS === 'ios' ? 'text-base' : "text-sm"} ${selectedDate[i] ? showDate[i] ? 'color-[#1873de]' : 'color-[#8e8e8e]' : showDate[i] ? 'color-[#1873de]' : 'color-[#c7c7c9]'} [font-family:'Poppins-Regular'] ${e.label ? 'text-right' : 'pl-4'}`} >
                      {selectedDate[i] ? Platform.OS === 'ios' ? moment(selectedDate[i]).format('DD MMM YYYY') : selectedDate[i] : 'Select Date'}
                    </Text> 
                  </TouchableOpacity>

                : e.type === 'date' ?

                  <TouchableOpacity 
                    style={{backgroundColor : 'transparent'}} className="p-3 pt-3.5 rounded-[16px]" 
                    onPress={()=> {
                      const cureentShow = [...showDate];
                      cureentShow[i] = !cureentShow[i];
                      setShowDate(cureentShow)
                    }}
                  > 
                    <Text className={`${Platform.OS === 'ios' ? 'text-base' : "text-sm"} ${selectedDate[i] ? showDate[i] ? 'color-[#1873de]' : 'color-[#8e8e8e]' : showDate[i] ? 'color-[#1873de]' : 'color-[#c7c7c9]'} [font-family:'Poppins-Regular'] ${e.label ? 'text-right' : 'pl-4'}`} >
                      {selectedDate[i] ? Platform.OS === 'ios' ? moment(selectedDate[i]).format('DD MMM YYYY') : selectedDate[i] : 'Select Date'}
                    </Text> 
                  </TouchableOpacity>

                : e.type === 'radio' ? 

                  <View className='p-2'>
                    <SegmentedControl
                      values={e.data} className={`${Platform.OS === 'ios' ? 'text-base' : "text-sm"} [font-family:'Poppins-Regular']`}
                      fontStyle={{fontFamily:'Poppins-Regular'}}
                      // activeFontStyle={{fontFamily:'Poppins-Regular'}}
                      // tabStyle={{fontFamily:'Poppins-Regular'}}
                      selectedIndex={radio[i] || e.default}
                      onChange={(event) => {
                        const rbtns = [...radio];
                        rbtns[i] = event.nativeEvent.selectedSegmentIndex;
                        setRadio(rbtns);
                      }}
                    />
                  </View> 

                : e.type === 'checkbox' ? 

                    <Checkbox.Item mode='ios' status={check[i] ? 'checked' : 'unchecked'} label={e.title} color='#1873de'
                      className={`p-1 pl-4 pr-4 ${Platform.OS === 'ios' ? 'text-base' : "text-sm"}`}
                      labelStyle={{ fontFamily:'Poppins-Regular'}}
                      onPress={(e)=> {
                        const chb = [...check];
                        chb[i] =  !chb[i];
                        setCheck(chb);
                      }}
                    />

                : e.type === 'select' ? 

                  <TouchableOpacity 
                    style={{backgroundColor : 'transparent'}} className="p-3 pt-3.5 rounded-[16px]" 
                    onPress={()=> {
                      navigation.navigate('AutoCompleteList', {
                        itemId: 86,
                        otherParam: 'anything you want here',
                      });
                    }}
                  > 
                    <Text className={`${Platform.OS === 'ios' ? 'text-base' : "text-sm"} color-[#8e8e8e] [font-family:'Poppins-Regular'] ${e.label ? 'text-right' : 'pl-1'}`} >
                      Select Language
                    </Text> 
                  </TouchableOpacity>

                : ''}

              </View>
              
          </View>}

          {showDate[i] ? <>
          <Animated.View style={styles.container} className='w-full bg-white overflow-hidden'>
            {Platform.OS === 'ios' ? <RNDateTimePicker mode='date' display='inline' value={selectedDate[i] ? selectedDate[i] : new Date()} 
            onChange={(e,date) => {
              const currentDate = [...selectedDate];
              currentDate[i] = date;
              setSelectedDate(currentDate);

              const cureentShow = [...showDate];
              cureentShow[i] = false;
              setShowDate(cureentShow)
            }} />
            : <DatePicker mode='caledar' 
            // selected={String(selectedDate[i]) ? String(selectedDate[i]) : ''}
            onSelectedChange={date => {
              const currentDate = [...selectedDate];
              currentDate[i] = date;
              setSelectedDate(currentDate);

              const cureentShow = [...showDate];
              cureentShow[i] = false;
              setShowDate(cureentShow)
            }}/>}
            </Animated.View></> : ''}
            {e.visible === false ? '' : data && data.length === i+1 ? '' : <Divider/>}
          
          </View>
        )
      })}
    </View>
    
    </>
  )
}

const styles = StyleSheet.create({
    container: {
        flex: 1,
        justifyContent: 'center',
        alignItems: 'center',
        shadowOffset: { height: 8,width:0 },
          shadowColor: 'rgba(149, 157, 165, 0.2)',  
          shadowOpacity: 0.3,  
          elevation: 3,
          zIndex:999,  
    },
})