import types from "../types";

const initial_state = {
    userData: {},
}

export default function(state= initial_state, action){
    switch (action.type) {
        case types.LOGIN:
            const data = action.payload
            return {userData: data} 

        case types.SIGNUP:
            const data_ = action.payload
            return {userData: data_}
            
        // case types.SENDOTP:
        //     const data__ = action.payload
        //     return {userData: data__}

        default:
            return {...state}
    }
}