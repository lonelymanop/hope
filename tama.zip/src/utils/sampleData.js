export const sampleData = [
  {
    id: 1,
    title: 'Room in the heart of Paris',
    description: 'Châtelet - Les Halles - Beaubourg',
    uri: 'https://images.unsplash.com/photo-1591825729269-caeb344f6df2?ixlib=rb-4.0.3&ixid=MnwxMjA3fDB8MHxwaG90by1wYWdlfHx8fGVufDB8fHx8&auto=format&fit=crop&w=2370&q=80',
  },
  {
    id: 2,
    title: 'Hôtel Boronali *** - Room w/ Balcony in Montmartre',
    description: 'Montmartre',
    uri: 'https://images.unsplash.com/photo-1564013799919-ab600027ffc6?ixlib=rb-4.0.3&ixid=MnwxMjA3fDB8MHxwaG90by1wYWdlfHx8fGVufDB8fHx8&auto=format&fit=crop&w=2370&q=80',
  },
  {
    id: 3,
    title: 'Studio apartment, quiet and bright',
    description: 'Batignolles',
    uri: 'https://images.unsplash.com/photo-1480074568708-e7b720bb3f09?ixlib=rb-4.0.3&ixid=MnwxMjA3fDB8MHxwaG90by1wYWdlfHx8fGVufDB8fHx8&auto=format&fit=crop&w=2374&q=80',
  },
  {
    id: 4,
    title: 'Paris is a 20-minute walk to the Eiffel Tower',
    description: 'Commerce - Dupleix',
    uri: 'https://images.unsplash.com/photo-1575517111478-7f6afd0973db?ixlib=rb-4.0.3&ixid=MnwxMjA3fDB8MHxwaG90by1wYWdlfHx8fGVufDB8fHx8&auto=format&fit=crop&w=2370&q=80',
  },
];
