import {
  View,
  Text,
  StyleSheet,
  SafeAreaView,
  TouchableOpacity,
  FlatList,
  Platform,
  Button,
} from 'react-native';
import React from 'react';
import Icon from 'react-native-vector-icons/MaterialCommunityIcons';
import PropertyListingItem from '../../components/PropertyListingItem';
import {sampleData} from '../../utils/sampleData';
import DrawerSceneWrapper from '../../components/DrawerSceneWrapper';
import actions from '../../redux/actions';
import { useSelector } from 'react-redux';

const Dashboard = ({navigation}) => {
  const userData = useSelector((state) => state.auth.userData)
  const {openDrawer} = navigation;

  const logout = () => {
    actions.logout();
  }
  return (
    // <SafeAreaView >
        <View style={{padding: 16, marginTop: openDrawer ? Platform.OS === 'android' ? 10 : 50 : 0}}>
          {/* <View style={styles.searchBar}>
            <TouchableOpacity onPress={() => navigation.getParent('LeftDrawer').openDrawer()}>
              <Icon name="menu" size={20} color="#666" />
            </TouchableOpacity>
            <Text className='w-[270px]' style={styles.searchTextPlaceHolder}>Search Here</Text>
            <TouchableOpacity onPress={() => navigation.getParent('RightDrawer').openDrawer()}>
              <Icon name="menu" size={20} color="#666" />
            </TouchableOpacity>
          </View> */}
          
          <View style={{top: 50 ,left: 10}}>
          <TouchableOpacity onPress={() => navigation.getParent('LeftDrawer').openDrawer()}>
              <Icon name="menu" size={20} color="#666" />
            </TouchableOpacity>
          <View >

          </View>
          <View style={{right:10,bottom:12}}>

          <Text>{userData.name}</Text>
            <Text style={{ marginBottom: 16 }}>{userData.email}</Text>
            <Button
                title="Logout"
                onPress={logout}
            />
          </View>
       
            
        </View>
          {/* <FlatList
            showsVerticalScrollIndicator={false}
            data={sampleData}
            renderItem={({item}) => <PropertyListingItem {...item} />}
          /> */}
        </View>
    // </SafeAreaView>
  );
};

export default Dashboard;

const styles = StyleSheet.create({
  container: {backgroundColor: '#fff', flex: 1, borderRadius:  Platform.OS === 'android' ? 20 : 50,overflow:'hidden'},
  wrapper: {padding: 16},
  // searchBar: {
  //   backgroundColor: '#fff',
  //   borderRadius: 60,
  //   padding: 16,
  //   flexDirection: 'row',
  //   alignItems: 'center',
  //   shadowOffset: {
  //     width: 0,
  //     height: 5,
  //   },
  //   shadowColor: '#000',
  //   shadowOpacity: 0.1,
  //   shadowRadius: 10,
  //   marginBottom: 12,
  // },
  // searchTextPlaceHolder: {
  //   color: '#666',
  //   marginLeft: 8,
  // },
});
