import * as React from 'react';
import { NavigationContainer, DefaultTheme } from '@react-navigation/native';
import { CardStyleInterpolators, createStackNavigator } from '@react-navigation/stack';
import { createNativeStackNavigator } from '@react-navigation/native-stack';
import { useSelector } from 'react-redux';
import MainStack from './MainStack';
import AuthStack from './AuthStack';

const StackPOP = createStackNavigator();
const StackMain = createNativeStackNavigator();

const MyTheme = {
  ...DefaultTheme,
  colors: {
    ...DefaultTheme.colors,
    background: 'transparent'
  },
};

const Navigation = () => {

  const userData = useSelector((state) => state.auth.userData)

  console.log("user data", userData.user)

  return (
    <NavigationContainer theme={MyTheme}>
      <StackPOP.Navigator screenOptions={{
        headerShown: false,
        // cardOverlayEnabled: true,
        // ...TransitionPresets.ModalPresentationIOS,
        // mode: 'modal',
        // headerMode: 'none',
        // cardStyle:{
        //   backgroundColor:"transparent",
        //    opacity:0.99
        // }
      }}>

        {(!!userData && userData?.token) ? MainStack(StackMain) : AuthStack(StackMain)}

      </StackPOP.Navigator>
    </NavigationContainer>
  );
};

export default Navigation;

{/* <StackPOP.Screen name="AutoCompleteList" component={AddEmployee} 
          options={{
            // presentation:'transparentModal',
            // gestureEnabled: true,
            // fullScreenGestureEnabled:true,
            // cardOverlayEnabled: true,
            // ...TransitionPresets.ModalPresentationIOS,
            // // cardStyleInterpolator: CardStyleInterpolators.forModalPresentationIOS,
            headerShown:true,
            gestureEnabled:true,
            presentation:'modal',
            ...TransitionPresets.ModalSlideFromBottomIOS,
            headerTitle:"AutoCompleteList",
            headerBackButtonMenuEnabled: true,
          }}/> */}
