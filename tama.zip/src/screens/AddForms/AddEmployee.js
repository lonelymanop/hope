import { View, Text, Image, TextInput, TouchableOpacity, StyleSheet, ScrollView, Platform, Pressable, SafeAreaView, Button } from 'react-native'
import { useNavigation } from "@react-navigation/native";
import React, { useEffect, useCallback, useState } from 'react';
import { useForm } from 'react-hook-form';
import SegmentedControl from '@react-native-segmented-control/segmented-control';

import * as ImagePicker from 'expo-image-picker';
import UserAvatar from 'react-native-user-avatar';
import TextFieldGroup from '../components/TextFieldGroup';
import CustomSelect from '../components/CustomSelect';

export default function AddEmployee() {
    const navigation = useNavigation();
    const [tab1, setTab1] = useState(0);
    const [tab2, setTab2] = useState(0);
    const [page, setPage] = useState(0);


    const [image, setImage] = useState(null);

    const pickImage = async () => {
        // No permissions request is necessary for launching the image library
        let result = await ImagePicker.launchImageLibraryAsync({
            mediaTypes: ImagePicker.MediaTypeOptions.All,
            allowsEditing: true,
            aspect: [4, 3],
            quality: 1,
        });

        console.log(result);

        if (!result.canceled) {
            setImage(result.assets[0].uri);
        }
    };




    const { register, handleSubmit, setValue } = useForm();

    const onSubmit = useCallback((formData) => {
        console.log(formData);
    }, []);

    const onChangeField = useCallback((name) => (text) => {
        setValue(name, text);
    }, []);

    useEffect(() => {
        register('email');
        register('password');
    }, [register]);

    return (
        <>
            <ScrollView className='w-full h-full bg-[#f3f2f7]' nestedScrollEnabled={true} directionalLockEnabled={true}>
                <View className="bg-white flex flex-row justify-center item-center w-full h-full">
                    <View className="bg-white w-full h-full relative bg-[#f3f2f7]">


                        <View className=" p-3 pt-0 ">
                            <View className="p-2">

                                <Text className="mt-2 text-center [font-family:'Poppins-Regular'] tracking-wider text-[13px] pl-[15]  w-full color-[#8e8e8e]">
                                    EMPLOYEE ID: EMPXX1234
                                </Text>

                                <View className="flex flex-row">

                                    <View className="w-[35%] pt-4" style={styles.container2}>
                                        <Pressable onPress={pickImage}>
                                            <UserAvatar size={80} name="John Doe" bgColors={['#dbdbe3', '#d0d1d6', '#c9cacf']}
                                                src={image}
                                            />
                                        </Pressable>
                                    </View>

                                    <View className="w-[65%]">
                                        <TextFieldGroup
                                            data={[{
                                                title: "First Name",
                                                type: "text",
                                                // label: true
                                            },
                                            {
                                                title: "Last Name",
                                                type: "text",
                                                // label: true
                                            }]}
                                        />
                                    </View>

                                </View>

                                {page === 0 ?
                                    <>

                                        <TextFieldGroup
                                            title={'General Details'}
                                            data={[
                                                {
                                                    title: "Gender",
                                                    type: "radio",
                                                    data: ['Male', 'Female', 'Other'],
                                                    default: 0,
                                                    label: true
                                                },
                                                {
                                                    title: "Date of Birth",
                                                    type: "date",
                                                    label: true
                                                },
                                                {
                                                    title: "Languages",  
                                                    type: "select",
                                                },
                                            ]}
                                        />

                                        {/* <Text className="mt-4 mb-1 [font-family:'Poppins-Regular'] tracking-wider text-[13px] pl-[15]  w-full color-[#8e8e8e]">
                                            {String('Languages').toUpperCase()}
                                        </Text>
                                        <CustomSelect/> */}

                                        <View className='mt-5'>
                                            <SegmentedControl
                                                values={['Contact', 'Family', 'Address']} className={`${Platform.OS === 'ios' ? 'text-base' : "text-sm"} [font-family:'Poppins-Regular']`}
                                                fontStyle={{ fontFamily: 'Poppins-Regular' }}
                                                // activeFontStyle={{fontFamily:'Poppins-Regular'}}
                                                // tabStyle={{fontFamily:'Poppins-Regular'}}
                                                selectedIndex={tab1}
                                                onChange={(event) => {
                                                    setTab1(event.nativeEvent.selectedSegmentIndex);
                                                }}
                                            />
                                        </View>

                                        <ScrollView className='w-full h-full bg-[#f3f2f7]' nestedScrollEnabled={true} directionalLockEnabled={true}>

                                        {tab1 === 0 &&
                                            <>

                                                <TextFieldGroup
                                                    title={'Contact Details'}
                                                    data={[
                                                        {
                                                            title: "Email",
                                                            type: "text",
                                                            label: true
                                                        },
                                                        {
                                                            title: "Phone 1",
                                                            type: "phone",
                                                            label: true
                                                        },
                                                        {
                                                            title: "Phone 2",
                                                            type: "phone",
                                                            label: true
                                                        },
                                                        // {
                                                        // title: "emergency contact",
                                                        //   type: "",
                                                        //   label:true
                                                        // },
                                                    ]}
                                                />

                                                    <Button title='Add Emergency Contacts' 
                                                        onPress={()=> navigation.navigate('AutoCompleteList', {
                                                        type: 0
                                                    })}/>

                                            </>}

                                        {tab1 === 1 &&
                                            <>
                                                <TextFieldGroup
                                                    title={'Family Details'}
                                                    data={[
                                                        {
                                                            title: "Father Name",
                                                            type: "text",
                                                            label: true
                                                        },
                                                        {
                                                            title: "Mother Name",
                                                            type: "text",
                                                            label: true
                                                        },
                                                        {
                                                            title: "Is Married",
                                                            type: "checkbox",
                                                            label: false
                                                        }]}
                                                />

                                                <TextFieldGroup
                                                    title={'Spouse Details'}
                                                    data={[
                                                        {
                                                            title: "Name",
                                                            type: "text",
                                                            visible: true,
                                                            label: true
                                                        },
                                                        {
                                                            title: "Phone",
                                                            type: "phone",
                                                            label: true
                                                        }]}
                                                />

                                                    <Button title='Add Dependents' 
                                                        onPress={()=> navigation.navigate('AutoCompleteList', {
                                                        type: 1
                                                    })}/>

                                            </>}

                                        {tab1 === 2 &&
                                            <>

                                                <TextFieldGroup
                                                    title={'Address Details'}
                                                    data={[
                                                        {
                                                            title: "Current Address",
                                                            type: "textarea",
                                                            lines: 2,
                                                            label: false
                                                        },
                                                        {
                                                            title: "Permanent Address",
                                                            type: "textarea",
                                                            lines: 2,
                                                            label: false
                                                        }]}
                                                />

                                            </>}

                                        </ScrollView>

                                    </> :
                                    page === 1 ?
                                        <>

                                            <View className='mt-5'>
                                                <SegmentedControl
                                                    values={['Education', 'Employment']} className={`${Platform.OS === 'ios' ? 'text-base' : "text-sm"} [font-family:'Poppins-Regular']`}
                                                    fontStyle={{ fontFamily: 'Poppins-Regular' }}
                                                    // activeFontStyle={{fontFamily:'Poppins-Regular'}}
                                                    // tabStyle={{fontFamily:'Poppins-Regular'}}
                                                    selectedIndex={tab2}
                                                    onChange={(event) => {
                                                        setTab2(event.nativeEvent.selectedSegmentIndex);
                                                    }}
                                                />
                                            </View>

                                            {tab2 === 0 &&
                                                <>
                                                    <Button title='Add Education' 
                                                        onPress={()=> navigation.navigate('AutoCompleteList', {
                                                        type: 2
                                                    })}/>
                                                   
                                                </>}

                                            {tab2 === 1 && <>
                                                <TextFieldGroup
                                                    title={'employement details'}
                                                    data={[
                                                        {
                                                            title: "Gross Salary",
                                                            type: "text",
                                                            label: true
                                                        },
                                                        {
                                                            title: "CTC",
                                                            type: "text",
                                                            label: true
                                                        },

                                                        {
                                                            title: "Assessment ",
                                                            type: "text",
                                                            label: true
                                                        },
                                                        {
                                                            title: "Joining Date",
                                                            type: "date",
                                                            label: true
                                                        }, {
                                                            title: "Resign Date",
                                                            type: "date",
                                                            label: true
                                                        },
                                                        {
                                                            title: "Reason of Resign",
                                                            type: "textarea",
                                                            lines: 2,

                                                        },
                                                        {
                                                            title: "Signature",
                                                            type: "text",
                                                            label: true

                                                        },
                                                    ]} />

                                                    <Button title='Add Pre Employment' 
                                                    onPress={()=> navigation.navigate('AutoCompleteList', {
                                                        type: 3
                                                      })}/>

                                                </>}

                                        </> : <>
                                        
                                            <TextFieldGroup
                                                title={'Compliance Details'}
                                                data={[
                                                    {
                                                        title: "Is Compliance",
                                                        type: "checkbox",
                                                        label: false
                                                    }]} />


                                            <TextFieldGroup
                                                title={'Nominee Details'}
                                                data={[
                                                    {
                                                        title: "Name",
                                                        type: "text",
                                                        label: true
                                                    },
                                                    {
                                                        title: "Relation",
                                                        type: "text",
                                                        label: true
                                                    }]} />


                                            <TextFieldGroup
                                                title={'Bank Details'}
                                                data={[
                                                    {
                                                        title: "Name",
                                                        type: "text",
                                                        label: true
                                                    },
                                                    {
                                                        title: "Linked Phone",
                                                        type: "phone",
                                                        label: true
                                                    },

                                                    {
                                                        title: "Bank Photo",
                                                        type: "text",
                                                        label: true
                                                    }]} />


                                            <TextFieldGroup
                                                title={'Other KYC Details'}
                                                data={[

                                                    {
                                                        title: "Aadhar Card",
                                                        type: "text",
                                                        label: true
                                                    },
                                                    {
                                                        title: "Add Pancard",
                                                        type: "text",
                                                        label: true
                                                    },
                                                    {
                                                        title: "Add Passbook",
                                                        type: "text",
                                                        label: true
                                                    },
                                                    {
                                                        title: "Add PVC",
                                                        type: "text",
                                                        label: true
                                                    },
                                                    {
                                                        title: "Add BVC",
                                                        type: "text",
                                                        label: true
                                                    },


                                                ]} />
                                        </>}


                            </View>

                        </View>


                    </View>
                </View>
            </ScrollView>
            <View className={`p-6 flex flex-row pt-4 bg-white ${Platform.OS === 'ios' ? 'pb-10' : 'pb-5'}`}>
                <View className='w-[50%] pr-2'>
                    <TouchableOpacity
                        style={styles.shadow} className=" w-full bg-sky-400 p-3 rounded-[16px] "
                        onPress={() => page >= 0 && setPage(page - 1)} disabled={page === 0 ? true : false}
                    >
                        <Text className="text-lg text-white [font-family:'Poppins-SemiBold'] text-center">
                            Previous</Text>
                    </TouchableOpacity>
                </View>

                <View className='w-[50%] pl-2'>
                    <TouchableOpacity
                        style={styles.shadow} className=" w-full bg-sky-400 p-3 rounded-[16px] "
                        onPress={() => page <= 2 && setPage(page + 1)}
                    >
                        <Text className="text-lg text-white [font-family:'Poppins-SemiBold'] text-center">
                            {page === 2 ? 'Submit' : 'Next'}</Text>
                    </TouchableOpacity>
                </View>
            </View>

        </>
    );
};

const styles = StyleSheet.create({
    shadow: {
        // box-shadow: rgba(99, 99, 99, 0.2) 0px 2px 8px 0px;
        // box-shadow: rgba(149, 157, 165, 0.2) 0px 8px 24px;
        // boxShadow: 'rgba(0, 0, 0, 0.35) 0px 5px 15px',
        shadowOffset: { height: 8, width: 0 },
        shadowColor: 'rgba(149, 157, 165, 0.2)',
        shadowOpacity: 0.3,
        elevation: 3,
        zIndex: 999,
    },
    container: {
        flex: 1,
        justifyContent: 'center',
        alignItems: 'center',
        shadowOffset: { height: 8, width: 0 },
        shadowColor: 'rgba(149, 157, 165, 0.2)',
        shadowOpacity: 0.3,
        elevation: 3,
        zIndex: 999,
    },
    searchBar: {
        borderWidth: 1,
        height: 40
    },
    container2: {
        flex: 1,
        alignItems: "center",
        justifyContent: "center",
        textAlign: 'center',
        verticalAlign: 'middle'
    },
    image: {
        width: 90,
        height: 90,
        shadowOffset: { height: 8, width: 0 },
        shadowColor: 'rgba(149, 157, 165, 0.2)',
        shadowOpacity: 0.3,
        elevation: 3,
    },
});

// text-[#34c2c1]
