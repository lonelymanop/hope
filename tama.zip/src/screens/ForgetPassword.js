import React, { useState, useEffect } from 'react';
import { View, Text, TextInput, TouchableOpacity, Image } from 'react-native';
import * as yup from 'yup';
import actions from '../redux/actions';
import FlashMessage, { showMessage } from 'react-native-flash-message';

const emailSchema = yup.object().shape({
  email: yup.string().email('Invalid email format').required('Email is required'),
});

const resetPasswordSchema = yup.object().shape({
  email: yup.string().email('Invalid email format').required('Email is required'),
  oldPassword: yup.string().required('Current password is required'),
  newPassword: yup.string()
    .required('New password is required')
    .min(6, 'Password must be at least 6 characters long'),
  confirmPassword: yup.string()
    .required('Confirm password is required')
    .oneOf([yup.ref('newPassword'), null], 'Passwords must match'),
});

export default function ForgottenPassword({ navigation }) {
  const [email, setEmail] = useState('');
  const [emailError, setEmailError] = useState('');
  const [showResetPasswordFields, setShowResetPasswordFields] = useState(false);
  const [formData, setFormData] = useState({
    email: '',
    oldPassword: '',
    newPassword: '',
    confirmPassword: '',
  });
  const [resetPasswordError, setResetPasswordError] = useState({});
  const [sentOtp, setSentOtp] = useState(false);
  const [timer, setTimer] = useState(60);

  const handleForgottenPassword = async () => {
    try {
      await emailSchema.validate({ email }, { abortEarly: false });
      try {
        const res = await actions.ForgotPassword({ email });
        console.log('Forgot Password Response ==>>>', res);
        showMessage({
          message: 'Password reset email sent',
          description: 'Please check your email for instructions to reset your password',
          type: 'success',
        });
        setFormData((prevFormData) => ({ ...prevFormData, email }));
        setShowResetPasswordFields(true);
        setSentOtp(true);
        startTimer();
      } catch (error) {
        console.log('Error during password reset:', error);
        showMessage({
          message: 'Error',
          description: 'Failed to send password reset email. Please try again.',
          type: 'error',
        });
      }
    } catch (err) {
      setEmailError(err.errors[0]);
    }
  };

  const handleResetPassword = async () => {
    try {
      await resetPasswordSchema.validate(formData, { abortEarly: false });
      try {
        const { email, oldPassword, newPassword, confirmPassword } = formData;
        const res = await actions.resetPassword({ email, oldPassword, newPassword, confirmPassword });
        console.log('Reset Password Response ==>>>', res);
        showMessage({
          message: 'Password reset successful',
          description: 'You can now login with your new password',
          type: 'success',
        });
        navigation.navigate('Login');
      } catch (error) {
        console.log('Error during password reset:', error);
        showMessage({
          message: 'Error',
          description: 'Failed to reset password. Please try again.',
          type: 'error',
        });
      }
    } catch (err) {
      const errors = {};
      err.inner.forEach((error) => {
        errors[error.path] = error.message;
      });
      setResetPasswordError(errors);
    }
  };

  const handleEmailChange = (text) => {
    setEmail(text);
    setEmailError('');
  };

  const handleFormDataChange = (field, text) => {
    setFormData((prevFormData) => ({ ...prevFormData, [field]: text }));
    setResetPasswordError((prevErrors) => ({ ...prevErrors, [field]: '' }));
  };

  const startTimer = () => {
    const interval = setInterval(() => {
      setTimer((prevTimer) => prevTimer - 1);
    }, 1000);

    setTimeout(() => {
      clearInterval(interval);
      setSentOtp(false);
      setTimer(60);
    }, 60000);
  };

  useEffect(() => {
    if (timer === 0) {
      setSentOtp(false);
      setTimer(60);
    }
  }, [timer]);

  return (
    <View className="flex-1 justify-center items-center px-6">
      <View className="flex items-center mb-8">
        <Image
          source={require('../../assets/images/wlogo.png')}
          resizeMode={'contain'}
          style={{ width: 200, height: 65 }}
        />
      </View>
      <Text className="text-2xl font-bold mb-8">Forgotten Password</Text>

      {!showResetPasswordFields && (
        <>
          <View className="w-full mb-6">
            <TextInput
              className="border border-gray-300 rounded-lg px-4 py-3 mb-2 focus:border-teal-500"
              value={email}
              onChangeText={handleEmailChange}
              placeholder="Email"
              keyboardType="email-address"
            />
            {emailError && <Text className="text-red-500 mt-1">{emailError}</Text>}
          </View>

          <TouchableOpacity
            className="bg-teal-500 rounded-lg px-4 py-3 w-full shadow-md mb-4"
            onPress={handleForgottenPassword}
          >
            <Text className="text-white text-lg font-semibold text-center">Send Reset Link</Text>
          </TouchableOpacity>

          <Text className="text-base mt-4 text-center">
            Already have an account?{' '}
            <Text className="text-teal-500 font-semibold" onPress={() => navigation.navigate('Login')}>
              Login
            </Text>
          </Text>
        </>
      )}

      {showResetPasswordFields && (
        <>
          <View className="w-full mb-4">
            <TextInput
              className="border border-gray-300 rounded-lg px-4 py-3 mb-2 focus:border-teal-500"
              placeholder="Email"
              keyboardType="email-address"
              value={formData.email}
              onChangeText={(text) => handleFormDataChange('email', text)}
              editable={false}
            />
            {resetPasswordError.email && <Text className="text-red-500 mt-1">{resetPasswordError.email}</Text>}
          </View>

          <View className="w-full mb-4">
            <TextInput
              className="border border-gray-300 rounded-lg px-4 py-3 mb-2 focus:border-teal-500"
              placeholder="Current Password"
              secureTextEntry
              value={formData.oldPassword}
              onChangeText={(text) => handleFormDataChange('oldPassword', text)}
            />
            {resetPasswordError.oldPassword && <Text className="text-red-500 mt-1">{resetPasswordError.oldPassword}</Text>}
          </View>

          <View className="w-full mb-4">
            <TextInput
              className="border border-gray-300 rounded-lg px-4 py-3 mb-2 focus:border-teal-500"
              placeholder="New Password"
              secureTextEntry
              value={formData.newPassword}
              onChangeText={(text) => handleFormDataChange('newPassword', text)}
            />
            {resetPasswordError.newPassword && <Text className="text-red-500 mt-1">{resetPasswordError.newPassword}</Text>}
          </View>

          <View className="w-full mb-6">
            <TextInput
              className="border border-gray-300 rounded-lg px-4 py-3 mb-2 focus:border-teal-500"
              placeholder="Confirm Password"
              secureTextEntry
              value={formData.confirmPassword}
              onChangeText={(text) => handleFormDataChange('confirmPassword', text)}
            />
            {resetPasswordError.confirmPassword && <Text className="text-red-500 mt-1">{resetPasswordError.confirmPassword}</Text>}
          </View>

          <TouchableOpacity
            className="bg-teal-500 rounded-lg px-4 py-3 w-full shadow-md mb-4"
            onPress={handleResetPassword}
          >
            <Text className="text-white text-lg font-semibold text-center">Reset Password</Text>
          </TouchableOpacity>

          <Text className="text-base mt-4 text-center">
            Already have an account?{' '}
            <Text className="text-teal-500 font-semibold" onPress={() => navigation.navigate('Login')}>
              Login
            </Text>
          </Text>
        </>
      )}

      {sentOtp && (
        <View className="absolute bottom-4 bg-teal-500 rounded-lg px-4 py-2">
          <Text className="text-white text-base">Resend in {timer} seconds</Text>
        </View>
      )}

      <FlashMessage position="top" />
    </View>
  );
}