import React, { useState } from 'react';
import { View, Text, TextInput, TouchableOpacity, Image } from 'react-native';
import * as yup from 'yup';
import actions from '../redux/actions';

const signupSchema = yup.object().shape({
  firstName: yup.string().required('First name is required'),
  lastName: yup.string().required('Last name is required'),
  email: yup.string().email('Invalid email format').required('Email is required'),
  phone: yup.string().required('Phone number is required'),
  password: yup.string()
    .required('Password is required')
    .min(6, 'Password must be at least 6 characters long'),
});

export default function SignUp({ navigation }) {
  const [formData, setFormData] = useState({
    firstName: '',
    lastName: '',
    email: '',
    phone: '',
    password: '',
  });
  const [errors, setErrors] = useState({});

  const handleSignUp = async () => {
    try {
      await signupSchema.validate(formData, { abortEarly: false });
      try {
        const { firstName, lastName, email, phone, password } = formData;
        const res = await actions.signup({
          name: `${firstName} ${lastName}`,
          email,
          phone,
          password,
        });
        console.log('Signup successful:', res);
      } catch (error) {
        console.log('Error during signup:', error.message);
      }
    } catch (err) {
      const errors = {};
      err.inner.forEach((error) => {
        errors[error.path] = error.message;
      });
      setErrors(errors);
    }
  };

  return (

    <View className="flex-1 justify-center px-8">
      <Text className="text-3xl font-bold ">Welcome to</Text>
      {/* <Text className="text-3xl font-extrabold  text-teal-500 mb-4">wareozo</Text> */}
      <Image
        source={require('../../assets/images/wlogo.png')}
        resizeMode={'contain'}
        style={{ width: 200, height: 65 }}
      />
      <Text className="text-base mb-5 mt-8">Create account with easy and fast methods</Text>
      <View className="flex flex-row p-2">
        <View className='w-[52%] pr-2 justify-around'>
          <TextInput
            className="border border-gray-100 rounded-lg p-3 mb-4 focus:border-teal-500 "
            value={formData.firstName}
            onChangeText={(text) => setFormData({ ...formData, firstName: text })}
            placeholder="First Name"
          />
        </View>

        <View  className='w-[52%] pl-2'>
          <TextInput
            className="border border-gray-100 rounded-lg p-3 mb-4 focus:border-teal-500 "
            value={formData.lastName}
            onChangeText={(text) => setFormData({ ...formData, lastName: text })}
            placeholder="Last Name"
          /></View>
      </View>

      <View className="flex-row items-center border  border-gray-100 rounded-lg mb-4   focus:border-teal-500">
        <Text className="px-3 py-3">+91</Text>
        <TextInput
          className="flex-1 p-3 focus:border-teal-500"
          value={formData.phone}
          onChangeText={(text) => setFormData({ ...formData, phone: text })}
          placeholder="Phone number"
          keyboardType="phone-pad"
        />
      </View>

      <TextInput
        className="border border-gray-100 rounded-lg p-3 mb-4 focus:border-teal-500"
        value={formData.email}
        onChangeText={(text) => setFormData({ ...formData, email: text })}
        placeholder="Email"
        keyboardType="email-address"
      />

      <TextInput
        className="border border-gray-100 rounded-lg p-3 mb-6 focus:border-teal-500"
        value={formData.password}
        onChangeText={(text) => setFormData({ ...formData, password: text })}
        placeholder="Password"
        secureTextEntry
      />

      <TouchableOpacity className="bg-[#01c8a7] rounded-lg px-4 py-3 shadow-md" onPress={handleSignUp}>
        <Text className="text-white text-lg font-semibold text-center">Sign Up</Text>
      </TouchableOpacity>
      <Text className="mt-4 text-center">
        Already have an account?{' '}
        <Text className="text-teal-500 font-semibold" onPress={() => navigation.navigate('Login')}>Login</Text>
      </Text>
    </View>
  );
};

