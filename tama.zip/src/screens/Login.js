import { useNavigation } from "@react-navigation/native";
import React, { useState } from 'react';
import { View, Text, TextInput, TouchableOpacity, Image } from 'react-native';
import * as yup from 'yup';
import actions from '../redux/actions';
import FlashMessage from 'react-native-flash-message';
import { showMessage } from 'react-native-flash-message';

const schema = yup.object().shape({
  emailOrPhone: yup
    .string()
    .matches(
      /^(([^<>()[\]\\.,;:\s@"]+(\.[^<>()[\]\\.,;:\s@"]+)*)|(".+"))@((\[[0-9]{1,3}\.[0-9]{1,3}\.[0-9]{1,3}\.[0-9]{1,3}\])|(([a-zA-Z\-0-9]+\.)+[a-zA-Z]{2,}))$|^(\+\d{1,2}\s)?\(?\d{3}\)?[\s.-]?\d{3}[\s.-]?\d{4}$/,
      'Invalid email or phone number format'
    )
    .required('Email or Phone Number is required'),
  password: yup
    .string()
    .required('Password is required')
    .min(6, 'Password must be at least 6 characters long'),
});

export default function Login() {
  const navigation = useNavigation();
  const [formData, setFormData] = useState({ email: '', password: '' });

  const handleLogin = async () => {
    try {
      // await schema.validate(formData, { abortEarly: false });
      const { email, password } = formData;
      console.log("Login data:",email, password);

      const res = await actions.login({ email, password });
      console.log("Login successful:", res.data);
      showMessage({
        message: 'Login successful',
        type: 'success',
      });
      // Navigate to the desired screen after successful login
    } catch (err) {
      if (err.message === 'Invalid email or phone number format') {
        showMessage({
          message: 'Please enter a valid email or phone number',
          type: 'danger',
        });
      } else if (err.message === 'Email or Phone Number is required') {
        showMessage({
          message: 'Email or Phone Number is required',
          type: 'danger',
        });
      } else if (err.message === 'Password is required') {
        showMessage({
          message: 'Password is required',
          type: 'danger',
        });
      } else if (err.message === 'Password must be at least 6 characters long') {
        showMessage({
          message: 'Password must be at least 6 characters long',
          type: 'danger',
        });
      } else {
        showMessage({
          message: 'Invalid email or phone number or password',
          type: 'danger',
        });
      }
    }
  };
  return (

    <View className="flex-1 justify-center px-8">
      <Text className="text-3xl font-bold ">Welcome to</Text>
      {/* <Text className="text-3xl font-extrabold  text-teal-500 mb-4">wareozo</Text> */}
      <Image
        source={require('../../assets/images/wlogo.png')}
        resizeMode={'contain'}
        style={{ width: 200, height: 65 }}
      />
      <Text className="text-base mb-5 mt-8">Login with easy and fast methods</Text>


   

      <TextInput
        className="border border-gray-100 rounded-lg p-3 mb-4 focus:border-teal-500"
        value={formData.email}
          onChangeText={(text) => setFormData({ ...formData, email: text })}
        placeholder="Email"
        keyboardType="email-address"
      />

      <TextInput
        className="border border-gray-100 rounded-lg p-3 mb-6 focus:border-teal-500"
        value={formData.password}
          onChangeText={(text) => setFormData({ ...formData, password: text })}
        placeholder="Password"
        secureTextEntry
      />


<View className="w-full mb-4 flex-row items-center justify-between">
     <TouchableOpacity  onPress={() => navigation.navigate('Loginotp')}>
        <Text className="text-teal-500 flex-start font-semibold">
          Login with OTP
        </Text>
      </TouchableOpacity>


        <TouchableOpacity onPress={() => navigation.navigate('ForgetPassword')}>
          <Text className="text-teal-500 font-semibold">Forgotten Password?</Text>
        </TouchableOpacity>
      </View>

      <TouchableOpacity className="bg-[#01c8a7] rounded-lg px-4 py-3 shadow-md"    onPress={handleLogin}>
        <Text className="text-white text-lg font-semibold text-center">Login</Text>
      </TouchableOpacity>

      <Text className="mt-4 text-center"     onPress={() => navigation.navigate('Register1')}>
        Don't have an account?{' '}
        <Text className="text-teal-500 font-semibold" >Signup</Text>
      </Text>
      
    </View>
  );
};
