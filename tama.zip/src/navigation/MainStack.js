import React from 'react';
import Parent from '../screens/Parent';
import AddEmployee from '../screens/AddForms/AddEmployee';
import AutoCompleteList from '../screens/components/AutoCompleteList';
import { TransitionPresets } from '@react-navigation/stack';

export default function (StackMain) {
    return (
        <>
            <StackMain.Screen name="Parent" component={Parent} />
            <StackMain.Screen name="AddEmployee" component={AddEmployee}
                options={{
                headerShown: true,
                gestureEnabled: true,
                fullScreenGestureEnabled: true,
                presentation: 'modal',
                ...TransitionPresets.ModalPresentationIOS,
                headerTitle: "Hello",
                headerBackButtonMenuEnabled: true
                }}
            />
            <StackMain.Screen name="AutoCompleteList" component={AutoCompleteList}
                options={{
                // headerShown:true,
                gestureEnabled: true,
                fullScreenGestureEnabled: true,
                presentation: 'modal',
                ...TransitionPresets.ModalPresentationIOS,
                headerTitle: "Hello",
                headerBackButtonMenuEnabled: true
                }}
            />
        </>
    )
}