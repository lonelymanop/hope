import { View, Text, Button,SafeAreaView, Platform, TouchableOpacity } from 'react-native'
import React from 'react'
import TextFieldGroup from './TextFieldGroup'
import { useNavigation } from '@react-navigation/native';
import { ScrollView } from 'react-native-gesture-handler';
import { StyleSheet } from 'react-native';
import AntDesign from 'react-native-vector-icons/AntDesign';

export default function AutoCompleteList({ route }) {

  const navigation = useNavigation();

  return (<>
  <View style={{ flex: 1 ,flexDirection: 'column', justifyContent: 'flex-end'}}>
  <View style={{ height:'fit-content',width: '100%', backgroundColor:"#f3f2f7",borderRadius:15, paddingTop:20}}>
  {/* <TouchableOpacity style={{ flexDirection: 'row', paddingRight: 12, justifyContent: 'space-between', paddingTop:12 }} onPress={() => navigation.goBack()}>
  <Text className="p-3 ">Emergency Contact</Text>
  <Ionicons name="close-circle-outline" size={28} color="black" style={{ marginLeft: 8, marginTop: 5 }} />
 
</TouchableOpacity> */}
{/* 
<View style={{ flexDirection: 'row', justifyContent: 'space-between', alignItems: 'center', paddingHorizontal: 16 }}>
  <View style={{ flexDirection: 'row', alignItems: 'center' }}>
    <Text style={{ color: 'black', fontWeight: 'bold' }}>Emergency Contacts</Text>
  </View>
  <TouchableOpacity
    style={{
      backgroundColor: 'rgba(0, 0, 0, 0.5)',
      padding: 8,
      borderRadius: 20,
    }}
    onPress={() => navigation.goBack()}
  >
    <AntDesign name="close" size={15} color="white" />
  </TouchableOpacity>
</View> */}

<View style={{ flexDirection: 'row', justifyContent: 'space-between', alignItems: 'center', paddingHorizontal: 16 }}>
  <Text className='text-[18px] text-bold font-bold font-medium text-black'>
    {route.params.type === 0
      ? 'Emergency Contacts'
      : route.params.type === 1
      ? 'Dependents Details'
      : route.params.type === 2
      ? 'Education Details'
      : route.params.type === 3
      ? 'Premployeer Details' :''}
  </Text>

  <TouchableOpacity
    style={{
      backgroundColor: 'rgb(235,235,235)',
      padding: 8,
      borderRadius: 20,
    }}
    onPress={() => navigation.goBack()}
  >
    <AntDesign name="close" size={15} color="#808080" />
  </TouchableOpacity>
</View>






    <ScrollView>
    <View className='p-6 pt-2 w-full'>
    {/* className={`p-3 w-full ${route.params.type === 0 ? '' :
    route.params.type === 1 ? 'h-[36%]' :
    route.params.type === 2 ? 'h-[70%]' :
    route.params.type === 3 ? 'h-[50%]' : ''}`}> */}

      {route.params.type === 0 ?

        <TextFieldGroup
          // title={'Emergency contacts'}
          data={[
            {
              title: "Name",
              type: "text",
              label: true
            },
            {
              title: "Phone",
              type: "phone",
              label: true
            },
            {
              title: "Relation",
              type: "relation",
              label: true
            }]}
        />

        : route.params.type === 1 ?

          <TextFieldGroup
            // title={'Dependents '}
            data={[
              {
                title: "Name",
                type: "text",
                label: true
              },
              {
                title: "Relation",
                type: "text",
                label: true
              },
              {
                title: "Date of Birth",
                type: "date",
                label: true
              },
              {
                title: "Phone",
                type: "phone",
                label: true
              }]}
          />

          : route.params.type === 2 ?

            <>

              <TextFieldGroup
                title={"School/College Name"}
                data={[
                  {
                    title: "School/College Name",
                    type: "text",
                    label: false
                  }]}
              />

              <TextFieldGroup
                title={"University Name"}
                data={[
                  {
                    title: "University Name",
                    type: "text",
                    label: false
                  }]} />

              <TextFieldGroup
                data={[
                  {
                    title: "Education ",
                    type: "text",
                    label: true
                  },
                  {
                    title: "Course",
                    type: "text",
                    label: true
                  },
                  {
                    title: "Start Date",
                    type: "date",
                    label: true
                  },
                  {
                    title: "End Date",
                    type: "date",
                    label: true
                  },
                  {
                    title: "Passing Year",
                    type: "date",
                    label: true
                  }, {
                    title: "Percentage",
                    type: "text",
                    label: true
                  },

                ]} />
            </>

            : route.params.type === 3 ?

              <TextFieldGroup
                // title={'Pre-Employer Details'}
                data={[
                  {
                    title: "Name",
                    type: "text",
                    label: true
                  },
                  {
                    title: "Title",
                    type: "text",
                    label: true
                  },
                  {
                    title: "Gross Salary",
                    type: "text",
                    label: true
                  },
                  {
                    title: "CTC",
                    type: "text",
                    label: true
                  },
                  {
                    title: "Start Date ",
                    type: "date",
                    label: true
                  },
                  {
                    title: "End Date",
                    type: "date",
                    label: true
                  },

                ]} /> : ''}
    </View>
    </ScrollView>
    <View className={`p-5 pt-6 bg-white ${Platform.OS === 'ios' ? 'pb-10' : 'pb-5'}`}>
                    <TouchableOpacity
                        style={styles.shadow} className=" w-full bg-[#007aff] p-2 rounded-[16px] "
                    >
                        <Text className="text-lg text-white [font-family:'Poppins-SemiBold'] text-center">
                            Submit</Text>
                    </TouchableOpacity>
            </View>

    </View>
  </View>
  </>
  )
}

const styles = StyleSheet.create({
  shadow: {
      // box-shadow: rgba(99, 99, 99, 0.2) 0px 2px 8px 0px;
      // box-shadow: rgba(149, 157, 165, 0.2) 0px 8px 24px;
      // boxShadow: 'rgba(0, 0, 0, 0.35) 0px 5px 15px',
      shadowOffset: { height: 8, width: 0 },
      shadowColor: 'rgba(149, 157, 165, 0.2)',
      shadowOpacity: 0.3,
      elevation: 3,
      zIndex: 999,
  },
  container: {
      flex: 1,
      justifyContent: 'center',
      alignItems: 'center',
      shadowOffset: { height: 8, width: 0 },
      shadowColor: 'rgba(149, 157, 165, 0.2)',
      shadowOpacity: 0.3,
      elevation: 3,
      zIndex: 999,
  },
  searchBar: {
      borderWidth: 1,
      height: 40
  },
  container2: {
      flex: 1,
      alignItems: "center",
      justifyContent: "center",
      textAlign: 'center',
      verticalAlign: 'middle'
  },
  image: {
      width: 90,
      height: 90,
      shadowOffset: { height: 8, width: 0 },
      shadowColor: 'rgba(149, 157, 165, 0.2)',
      shadowOpacity: 0.3,
      elevation: 3,
  },
});