
import { LOGIN, SENDOTP, SIGNUP,FORGOTPASSWORD,RESETPASSWORD } from "../../config/urls";
import { apiPost, clearUserData, setUserData } from "../../utils/utils";
import store from "../store";
import types from "../types";

const { dispatch } = store

export const saveUserData = (data, type) => {
    dispatch({
        type: type,
        payload: data
    })
}

export function login(data) {
    return new Promise((resolve, reject) => {
        return apiPost(LOGIN, data).then((res) => {
            if (res) {
                setUserData(res).then(() => {
                    resolve(res)
                    saveUserData(res, types.LOGIN)
                });
                return
            }
            resolve(res)
        }).catch((error) => {
            reject(error)
        })
    })
}

export function signup(data) {
    return new Promise((resolve, reject) => {
        return apiPost(SIGNUP, data).then((res) => {
            if (res) {
                setUserData(res).then(() => {
                    resolve(res)
                    saveUserData(res, types.SIGNUP)
                });
                return
            }
            resolve(res)
        }).catch((error) => {
            reject(error)
        })
    })
}

export function sendotp(data) {
    return new Promise((resolve, reject) => {
        return apiPost(SENDOTP, data).then((res) => {
            resolve(res)
        }).catch((error) => {
            reject(error)
        })
    })
}


export function ForgotPassword(data) {
    return new Promise((resolve, reject) => {
        return apiPost(FORGOTPASSWORD, data).then((res) => {
            resolve(res)
        }).catch((error) => {
            reject(error)
        })
    })
}


export function resetPassword(data) {
    return new Promise((resolve, reject) => {
        return apiPost(RESETPASSWORD, data).then((res) => {
            resolve(res)
        }).catch((error) => {
            reject(error)
        })
    })
}

export function logout(){
    dispatch({type: types.CLEAR_REDUX_STATE})
    clearUserData()
}