import { View, Text } from 'react-native'
import React, { useState } from 'react'
import DropDownPicker from 'react-native-dropdown-picker';

export default function CustomSelect() {

    const [open, setOpen] = useState(false);
    const [value, setValue1] = useState([]);
    const [items, setItems] = useState([
        {label: 'Hindi', value: 'hindi'},
        {label: 'English', value: 'english'},
        {label: 'Marathi', value: 'marathi'},
        {label: 'Italy', value: 'italy'},
        {label: 'Rome', value: 'rome'},
        {label: 'Finland', value: 'finland'}
    ]);

    return (
    <DropDownPicker placeholder='Select Languages' 
          open={open}
          value={value}
          items={items}
          setOpen={setOpen}
          setValue={setValue1}
          setItems={setItems}
          theme="LIGHT"
          multiple={true}
          style={{
            borderColor:'#fff',
            borderRadius:'10px',
          }}
          zIndex={0}
          zIndexInverse={false}
          itemSeparator={true}
          badgeProps={{
            style:{ 
              backgroundColor:'#f3f2f7',
              padding:5,
              paddingLeft:8,
              paddingRight:8,
              borderRadius:7
            }
          }}
          itemSeparatorStyle={{
            height:1,
            backgroundColor:'#eaeaea',
            // marginLeft:10,
            // marginRight:10
          }}
          closeAfterSelecting={true}
          listChildLabelStyle={{
            color: "#8e8e8e",
            borderTopColor:'black',
            borderTopWidth: '10px',
            fontFamily:'Poppins-Regular',
            fontSize:'16px',
          }}
          listParentContainerStyle={{
            height: 43
          }}
          modalAnimationType='slide'
          badgeTextStyle={{
            color:'#8e8e8e',
            fontFamily:'Poppins-Regular',
            fontSize: '16px'
          }}
          showBadgeDot={false}
          textStyle={{
            color: "#8e8e8e",
            fontFamily:'Poppins-Regular',
            fontSize:'16px'
          }}
          placeholderStyle={{
            color: "#c7c7c9",
            fontFamily:'Poppins-Regular',
            fontSize:'16px'
          }}
          containerStyle={{
            shadowOffset: { height: 8,width:0 },
            shadowColor: 'rgba(149, 157, 165, 0.2)',  
            shadowOpacity: 0.4,  
            elevation: 3,
          }}
          dropDownContainerStyle={{
            borderTopWidth:3,
            borderRadius:'10px',
            borderTopColor:'#eaeaea',
            backgroundColor: "#fff",
            borderColor:'#fff',
            shadowOffset: { height: 8,width:0 },
            shadowColor: 'rgba(149, 157, 165, 0.2)',  
            shadowOpacity: 0.3,  
            elevation: 3,
            maxHeight:223
          }}
          autoScroll={true}
          mode="BADGE"
          // badgeDotColors={["#e76f51", "#00b4d8", "#e9c46a", "#e76f51", "#8ac926", "#00b4d8", "#e9c46a"]}
        />
  )
}