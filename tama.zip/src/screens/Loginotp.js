import { useNavigation } from "@react-navigation/native";
import React, { useState, useEffect } from 'react';
import { View, Text, TextInput, TouchableOpacity,Image } from 'react-native';
import * as yup from 'yup';
import FlashMessage, { showMessage } from 'react-native-flash-message';
import actions from '../redux/actions';

const schema = yup.object().shape({
    credential: yup.string().required('Email or phone number is required'),
});

export default function Login() {
    const navigation = useNavigation();
    const [formData, setFormData] = useState({ credential: '' });
    const [errors, setErrors] = useState({});
    const [otpSent, setOtpSent] = useState(false);
    const [otp, setOtp] = useState('');
    const [timer, setTimer] = useState(0);
    const [credentialOTPSent, setCredentialOTPSent] = useState('');
    const otpInputRefs = Array(6).fill().map(() => React.createRef());

    const handleSendOTP = async () => {
        try {
            await schema.validate(formData, { abortEarly: false });
            const { credential } = formData;
            // Replace with your actual OTP sending logic
            const res = await actions.sendotp({ email: credential });
            console.log("OTP sent successfully:", credential);

            showMessage({
                message: 'OTP sent successfully',
                description: `OTP sent to ${credential}`,
                type: 'success',
            });
            setTimer(60); // Set the timer to 60 seconds
            setOtpSent(true);
            setCredentialOTPSent(credential);
        } catch (err) {
            const errors = {};
            if (err.inner && Array.isArray(err.inner)) {
                err.inner.forEach((error) => {
                    errors[error.path] = error.message;
                });
            }
            setErrors(errors);
        }
    };

    const handleOTPVerification = async () => {
        try {
            const { credential } = formData;
            const res = await actions.login({ email: credential, otp });
            console.log("OTP verification successful:", res.data);
            showMessage({
                message: 'Login successful',
                type: 'success',
            });
            // Navigate to the desired screen after successful login
        } catch (error) {
            console.log("Error during OTP verification:", error.message);
            showMessage({
                message: 'Error',
                description: 'Invalid OTP. Please try again.',
                type: 'danger',
            });
        }
    };

    const handleResendOTP = async () => {
        try {
            const { credential } = formData;
            const res = await actions.sendotp({ email: credential });

            console.log("OTP sent successfully:", res.data);
            showMessage({
                message: 'OTP sent successfully',
                description: `OTP sent to ${credential}`,
                type: 'success',
            });
            setTimer(60); // Set the timer to 60 seconds
        } catch (err) {
            const errors = {};
            if (err.inner && Array.isArray(err.inner)) {
                err.inner.forEach((error) => {
                    errors[error.path] = error.message;
                });
            }
            setErrors(errors);
        }
    };

    useEffect(() => {
        let interval = null;
        if (otpSent && timer > 0) {
            interval = setInterval(() => {
                setTimer(timer - 1);
            }, 1000);
        } else if (timer === 0) {
            clearInterval(interval);
        }
        return () => clearInterval(interval);
    }, [otpSent, timer]);

    const handleOTPChange = (index, value) => {
        const newOTP = otp.split('');
        newOTP[index] = value;
        setOtp(newOTP.join(''));

        if (value !== '' && index < 5) {
            otpInputRefs[index + 1].current.focus();
        } else if (value === '' && index > 0) {
            otpInputRefs[index - 1].current.focus();
        }
    };

    return (
        <View className="flex-1 justify-center items-center  px-5">
          <View className=' flex items-center mb-5' >

<Image
  source={require('../../assets/images/wlogo.png')}
  resizeMode={'contain'}
  style={{ width: 200, height: 65 }}
/>
</View>
            {!otpSent && (
                <View className="w-full mb-6">
               
                     <TextInput
                        className={`border border-gray-100 rounded-lg p-3 mb-4 focus:border-teal-500 ${errors.credential ? 'border-2 border-red-500' : ''}`}
                        placeholder="Email or Phone Number"
                        keyboardType={/^\d+$/.test(formData.credential) ? 'phone-pad' : 'email-address'}
                        value={formData.credential}
                        onChangeText={(text) => setFormData({ ...formData, credential: text })}
                    />
                    {errors.credential && <Text className="text-red-500 mb-2">{errors.credential}</Text>}
                    <TouchableOpacity
                        className="bg-teal-500 rounded-lg px-4 py-3 shadow-md"
                        onPress={handleSendOTP}
                    >
                        <Text className="text-white font-bold text-center">Send OTP</Text>
                    </TouchableOpacity>
                </View>
            )}

            {otpSent && (
                <View className="w-full mb-6">
                    <Text className="text-gray-700 mb-2">OTP sent to {credentialOTPSent}</Text>
                    <View className="w-full mb-6 flex-row justify-between">
                        {[0, 1, 2, 3, 4, 5].map((index) => (
                            <TextInput
                                key={index}
                                ref={otpInputRefs[index]}
                                className="bg-white rounded-lg px-4 py-3 w-[50px] shadow-md text-center"
                                placeholder="_"
                                keyboardType="numeric"
                                maxLength={1}
                                value={otp[index] || ''}
                                onChangeText={(text) => handleOTPChange(index, text)}
                                onKeyPress={({ nativeEvent }) => {
                                    if (nativeEvent.key === 'Backspace' && otp[index] === '') {
                                        if (index > 0) {
                                            otpInputRefs[index - 1].current.focus();
                                        }
                                    }
                                }}
                            />
                        ))}
                    </View>
                    <View className="flex-row justify-between">
                        <TouchableOpacity
                            className="bg-teal-500 rounded-lg px-4 py-3 flex-1 mr-2 shadow-md"
                            onPress={handleOTPVerification}
                        >
                            <Text className="text-white font-semibold text-lg text-center">Verify OTP</Text>
                        </TouchableOpacity>
                        <TouchableOpacity
                            className="bg-teal-500 rounded-lg px-4 py-3 flex-1 shadow-md"
                            onPress={handleResendOTP}
                        >
                            <Text className="text-white font-semibold text-lg text-center">Resend OTP</Text>
                        </TouchableOpacity>
                    </View>
                </View>
            )}

            <Text className="text-gray-700 mb-4">
                Don't have an account!{' '}
                <Text
                    className="text-teal-500 font-bold"
                    onPress={() => navigation.navigate('Register1')}
                >
                    Sign up now
                </Text>
            </Text>
            <FlashMessage position="top" />
        </View>
    );
}