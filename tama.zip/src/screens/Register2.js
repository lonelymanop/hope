import React, { useEffect } from "react";
import { View, Text, Image, TextInput, TouchableOpacity, StyleSheet, ScrollView } from 'react-native' 
import { useNavigation } from "@react-navigation/native";

import actions from '../redux/actions';

export default function Register2() {
    const navigation = useNavigation();

    const handleRegister = async () => {
        // try {
        //   const name = "abcd";
        //   const email = "abcd@mail.com";
        //   const phone = "7878787879";
        //   const password = "abcd#123";
        //   const res = await actions.signup({
        //     name, email, phone, password
        //   })
        //   console.log("res==>>>>>", res)
        // } catch (error) {
        //   console.log("error raised", error.message);
        // }
        navigation.navigate('SendOTP')

        // try {
        //   const email = "+918208222895";
        //   const res = await actions.sendotp({
        //     email
        //   })
        //   console.log("res==>>>>>", res)
        // } catch (error) {
        //   console.log("error raised", error.message);
        // }
    };
  

  return (
    <ScrollView className='w-full h-full bg-[#f7f7f7]'>
    <View className="bg-white flex flex-row justify-center item-center w-full h-full">
      <View className="bg-white w-full h-full relative bg-[#f7f7f7]">
        <Text className="pt-28 [font-family:'Poppins-SemiBold']  text-dark text-2xl text-center  leading-[normal] whitespace-nowrap">
          Register Now
        </Text>
        <View className="p-3 mt-10">
            <View className="p-2"> 
                <TextInput style={styles.shadow} className="[font-family:'Poppins-Medium'] text-base  w-full bg-white  rounded-[16px] p-4 pl-5" placeholder='Username' placeholderTextColor={'gray'}/>
            </View>
            <View className="p-2"> 
                <TextInput style={styles.shadow} className="[font-family:'Poppins-Medium'] text-base  w-full bg-white rounded-[16px] p-4 pl-5" placeholder='Password' secureTextEntry placeholderTextColor={'gray'}/> 
            </View>

            <View className="p-2 mt-20 pt-4"> 
                <TouchableOpacity style={styles.shadow} className="w-full bg-sky-400 p-4 rounded-[16px] mb-3" onPress={handleRegister}> 
                    <Text className="text-xl text-white [font-family:'Poppins-SemiBold'] text-center">Send OTP</Text> 
                </TouchableOpacity> 
            </View>
              {/* <Image
                className="absolute w-[205px] h-[156px] top-0 left-[85px]"
                alt="Google button"
                src="google-button.png"
              />
              <Image
                className="absolute w-[177px] h-[156px] top-0 left-0"
                alt="Facebook button"
                src="facebook-button.png"
              />
              <Image
                className="absolute w-[177px] h-[156px] top-0 left-[198px]"
                alt="Apple button"
                src="apple-button.png"
              /> */}
              <View className="">
                <Text className="[font-family:'Poppins-Medium'] text-dark-gray text-[15px] text-center ">
                  Or Continue with
                </Text>
                {/* <Image className="left-0 absolute w-[103px] h-px top-[8px] object-cover" alt="Line" src="line-1.svg" />
                <Image
                  className="left-[228px] absolute w-[103px] h-px top-[8px] object-cover"
                  alt="Line"
                  src="line-2.svg"
                /> */}
              </View>
        </View>
        <Text className="mt-28 text-center " onPress={()=> navigation.push('Login')}>
            <Text className="[font-family:'Poppins-Medium'] text-[#1e232c] text-[16px]">
                Already have an account?
            </Text>
            <Text className="[font-family:'Poppins-Medium'] text-sky-400 text-[16px]">
                {' '}Login Now
            </Text>
        </Text>
      </View>
    </View>
    </ScrollView>
  );
};

const styles = StyleSheet.create({  
    shadow: {  
        // box-shadow: rgba(99, 99, 99, 0.2) 0px 2px 8px 0px;
        // box-shadow: rgba(149, 157, 165, 0.2) 0px 8px 24px;
        // boxShadow: 'rgba(0, 0, 0, 0.35) 0px 5px 15px',
        shadowOffset: { height: 8,width:0 },
        shadowColor: 'rgba(149, 157, 165, 0.2)',  
        shadowOpacity: 0.3,  
        elevation: 3,
        zIndex:999,  
    }
});

// text-[#34c2c1]