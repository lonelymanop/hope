import React, {useEffect} from 'react';
import {BackHandler} from 'react-native';
import DrawerNavigator from '../navigation/drawer'

export default function Parent() {
  
  useEffect(() => {
    const backHandler = BackHandler.addEventListener('hardwareBackPress', () => true)
    return () => backHandler.remove()
  }, [])

  return <DrawerNavigator/>
}