import React from 'react';
import OnboardingScreen from '../screens/OnboardingScreen';
import Login from '../screens/Login';
import Register1 from '../screens/Register1';
// import Register2 from '../screens/Register2';
import SendOTP from '../screens/SendOTP';
import ForgetPassword from '../screens/ForgetPassword';
import Loginotp from '../screens/Loginotp'

export default function (StackMain) {
    return (
        <>
            <StackMain.Screen name="Onboard" component={OnboardingScreen} />
            <StackMain.Screen name="Login" component={Login} />
            <StackMain.Screen name="Loginotp" component={Loginotp} />
            <StackMain.Screen name="Register1" component={Register1} />
            {/* <StackMain.Screen name="Register2" component={Register2} /> */}
            <StackMain.Screen name="SendOTP" component={SendOTP} />
            <StackMain.Screen name="ForgetPassword" component={ForgetPassword} />

        </>
    )
}